export class RegisterUser{ 
  "userName": string; 
  "password": string; 
  "password2": string; 
}